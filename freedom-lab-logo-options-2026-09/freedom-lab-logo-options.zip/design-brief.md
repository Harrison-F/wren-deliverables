# Freedom Lab logo refresh — working brief

## User direction

- Create four materially different logo options.
- Preserve the core story: a digital Statue of Liberty torch.
- Treat the green as both Statue-of-Liberty patina and a digital/technical signal.
- Balance continuity with freedom to materially reinterpret the existing silhouette.
- Build a versatile master brand for web, physical signage, merchandise, and social avatars.
- Green-dominant palette with one accent color per direction.
- Provide both `Freedom Lab` and `Freedom Lab NYC` lockups.
- Avoid generic crypto symbols and circuit-board clichés.

## Exact source assets

The current brand family uses an electric-green, deliberately pixelated Statue of Liberty torch and hand on black, paired with block/pixel typography. The Drive originals are preserved under `references/` and documented in `provenance.json`.

## Current-mark audit

### Preserve

- Torch/flame story and clear Statue of Liberty association.
- Electric/statue green on a high-contrast field.
- Digital edge language.
- Tall, forward-rising two-point flame silhouette.
- Direct, sturdy typography rather than delicate editorial styling.

### Improve

- The hand, crown windows, shading, and many tiny pixels collapse at favicon/embroidery scale.
- Multiple source compositions are inconsistent and do not form one coherent responsive system.
- The current wordmark is expressive but can read as retro-game typography rather than durable civic technology.
- Tight internal gaps and thin one-pixel details weaken small-size reproduction.
- The full illustration is more mascot/artwork than a compact, ownable brand mark.

## Allan Peters principles applied

From *Logos That Last*:

1. Balance simplicity with originality; avoid both generic primitives and overbuilt illustration.
2. Preserve the story while removing elements until the concept reaches its simplest effective form.
3. Make the mark work at 16 × 16 pixels, in embroidery, and as a physical stamp.
4. Use thick geometry and generous negative space.
5. Combine brand nouns through negative space, overlap, rhythm, or an unexpected twist.
6. Vectorize on a clear grid and communicate the idea in the fewest moves.
7. Test symbols in black and white before relying on typography or color.
8. Extend the mark's geometry into a modular system of icon, horizontal lockup, vertical lockup, and optional badge.

## Concept families

1. **Signal Torch** — the closest evolution: radical simplification of the pixel/grid DNA.
2. **Liberty Aperture** — torch + open doorway/gathering place through negative space.
3. **Civic Beacon** — confident civic/institutional torch with subtle digital notches.
4. **Open Flame** — the freest interpretation, with `F`/`L` geometry hidden in the torch structure.
