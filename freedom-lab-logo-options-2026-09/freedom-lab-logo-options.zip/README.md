# Freedom Lab logo concepts

Four vector-first identity directions developed from the exact Freedom Lab `Assets/Logos` Drive files and Allan Peters' *Logos That Last*.

## Recommendation

**Advance Liberty Aperture (02).** It has the clearest original story—Liberty's torch plus an open door—while remaining simple enough for signage, merchandise, social avatars, and small digital use.

- **01 Signal Torch:** strongest continuity with the existing pixel identity.
- **02 Liberty Aperture:** strongest overall balance of story, originality, and simplicity.
- **03 Civic Beacon:** strongest institutional/civic posture.
- **04 Open Flame:** most experimental; the angular torch contains a visible `F` and an `L`-shaped handle.

## Included files

For each direction:

- `*-icon.svg` / `*.png` — color symbol
- `*-icon-mono.svg` / `*.png` — one-color symbol
- `*-freedom-lab.svg` / `*.png` — Freedom Lab lockup
- `*-freedom-lab-nyc.svg` / `*.png` — Freedom Lab NYC lockup
- `*-board.svg` / `*.png` — presentation board

Shared review files:

- `freedom-lab-logo-options-contact-sheet.png`
- `small-size-stress-test.png`
- `design-brief.md`
- `provenance.json`
- `generate_logos.py` — deterministic editable source generator

## Design rules used

- Torch recognition comes from the outer silhouette, not tiny illustration detail.
- Thick geometry and open counters replace the current hand, crown ornament, shading, and one-pixel noise.
- Every direction works in one color before the accent is applied.
- Digital character comes from grid logic, not circuit traces or crypto iconography.
- `NYC` is subordinate and uses the accent color.

## Production note

These are concept-stage vector masters. The selected direction should receive a final optical-spacing pass, outlined wordmark files, and a trademark/similarity screen before public adoption.
