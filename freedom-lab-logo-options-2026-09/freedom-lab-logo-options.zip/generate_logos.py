from pathlib import Path
from html import escape

ROOT = Path(__file__).resolve().parent
SVG_DIR = ROOT / "svg"
SVG_DIR.mkdir(parents=True, exist_ok=True)

OPTIONS = {
    "01-signal-torch": {
        "number": "01",
        "name": "Signal Torch",
        "thesis": "The existing pixel torch reduced to one bold grid-built signal.",
        "green": "#39F04A",
        "accent": "#315CFF",
        "bg": "#050706",
        "fg": "#F1F6F2",
        "font": "DIN Condensed, Avenir Next Condensed, Arial Narrow, sans-serif",
        "tracking": "3",
    },
    "02-liberty-aperture": {
        "number": "02",
        "name": "Liberty Aperture",
        "thesis": "A torch whose lit doorway turns liberty into an open gathering place.",
        "green": "#35D68A",
        "accent": "#FFB21A",
        "bg": "#07100C",
        "fg": "#F3F6ED",
        "font": "Avenir Next, Arial, sans-serif",
        "tracking": "1",
    },
    "03-civic-beacon": {
        "number": "03",
        "name": "Civic Beacon",
        "thesis": "A calmer civic mark with architectural weight and digital notches.",
        "green": "#249E70",
        "accent": "#173B67",
        "bg": "#F3F0E8",
        "fg": "#142219",
        "font": "Avenir Next, Arial, sans-serif",
        "tracking": "4",
    },
    "04-open-flame": {
        "number": "04",
        "name": "Open Flame",
        "thesis": "A torch-first symbol with F/L geometry hidden in flame and handle.",
        "green": "#49E05B",
        "accent": "#FF6B49",
        "bg": "#070807",
        "fg": "#F3F6F2",
        "font": "DIN Condensed, Avenir Next Condensed, Arial Narrow, sans-serif",
        "tracking": "2",
    },
}


def icon_signal(green, accent, mono=False):
    a = green if mono else accent
    return f'''<g id="mark">
  <!-- Twin-point flame built on a 32-unit modular grid. -->
  <path fill="{green}" d="M112 280V184h32v-32h32v-40h32V64h40v120h32v-32h32v-32h32V72h40v120h-32v40h-32v32h-40v32H160v-16z"/>
  <!-- Open negative channel keeps the flame legible at small sizes. -->
  <!-- Simplified torch cup: three large apertures, no illustrative crown detail. -->
  <rect fill="{green}" x="88" y="304" width="336" height="32" rx="4"/>
  <path fill="{green}" fill-rule="evenodd" d="M112 336h288l-40 88H152zm56 24v40h40v-40zm68 0v40h40v-40zm68 0v40h40v-40z"/>
  <rect fill="{green}" x="136" y="424" width="240" height="28" rx="3"/>
  <rect fill="{green}" x="216" y="452" width="80" height="44" rx="3"/>
  <rect fill="{a}" x="240" y="460" width="32" height="28" rx="2"/>
</g>'''


def icon_aperture(green, accent, mono=False):
    a = green if mono else accent
    return f'''<g id="mark">
  <defs>
    <mask id="aperture-cut">
      <rect width="512" height="512" fill="white"/>
      <path fill="black" d="M220 184Q256 142 292 184V286h-72z"/>
    </mask>
  </defs>
  <!-- One flame silhouette; the central cutout is an open doorway. -->
  <path fill="{green}" mask="url(#aperture-cut)" d="M258 44C196 98 160 154 164 212c4 54 36 88 92 104 60-18 94-56 92-112-1-39-25-72-7-130-43 28-71 62-86 103-18-35-22-83 3-133z"/>
  <path fill="{a}" d="M244 190Q256 174 268 190v86h-24z"/>
  <rect fill="{green}" x="112" y="312" width="288" height="30" rx="15"/>
  <path fill="{green}" d="M140 350h232l-32 64H172z"/>
  <rect fill="{green}" x="164" y="418" width="184" height="26" rx="13"/>
  <path fill="{green}" d="M222 444h68l14 52h-96z"/>
</g>'''


def icon_civic(green, accent, mono=False):
    a = green if mono else accent
    return f'''<g id="mark">
  <defs>
    <mask id="civic-cut">
      <rect width="512" height="512" fill="white"/>
      <path fill="black" d="M226 136v56c0 34 12 62 38 84-13 7-26 12-39 15-32-26-48-58-48-96 0-25 16-43 49-59z"/>
    </mask>
  </defs>
  <!-- Broad civic flame with one decisive internal cleft. -->
  <path fill="{green}" mask="url(#civic-cut)" d="M142 270c-19-57 7-116 88-182v88c0 30 12 53 34 70 14-48 50-98 112-146-4 55 20 82 2 128-18 45-57 70-118 86-58-14-103-21-118-44z"/>
  <!-- The cup borrows from the old crown, reduced to three architectural bays. -->
  <rect fill="{green}" x="102" y="304" width="308" height="32" rx="4"/>
  <path fill="{green}" fill-rule="evenodd" d="M126 344h260l-24 74H150zm54 14v42h36v-42zm58 0v42h36v-42zm58 0v42h36v-42z"/>
  <rect fill="{green}" x="128" y="424" width="256" height="28" rx="4"/>
  <path fill="{a}" d="M190 464h132l-16 32H206z"/>
</g>'''


def icon_open(green, accent, mono=False):
    a = green if mono else accent
    return f'''<g id="mark">
  <!-- An outlined angular flame makes this direction structurally distinct. -->
  <path fill="none" stroke="{green}" stroke-width="34" stroke-linecap="square" stroke-linejoin="miter" d="M154 282V190l78-108v132l124-112v136l-54 44"/>
  <!-- The connected interior bars quietly form an F. -->
  <path fill="{green}" d="M174 164h108v30h-70v38h56v30h-56v40h-38z"/>
  <path fill="{a}" d="M286 258l48-96v96z"/>
  <!-- Two strokes create the torch cup; the handle finishes as an L. -->
  <path fill="none" stroke="{green}" stroke-width="30" stroke-linecap="square" d="M112 326h288M150 382h212"/>
  <path fill="none" stroke="{green}" stroke-width="34" stroke-linecap="square" stroke-linejoin="miter" d="M222 398v82h112"/>
</g>'''


def bg_for_cut():
    # Replaced per-icon by a mask-safe transparent cut during assembly.
    return "#000000"


ICON_FUNCS = {
    "01-signal-torch": icon_signal,
    "02-liberty-aperture": icon_aperture,
    "03-civic-beacon": icon_civic,
    "04-open-flame": icon_open,
}


def svg_doc(body, viewbox, width=None, height=None, bg=None, extra=""):
    w_attr = f' width="{width}"' if width else ""
    h_attr = f' height="{height}"' if height else ""
    bg_rect = f'<rect width="100%" height="100%" fill="{bg}"/>' if bg else ""
    return f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="{viewbox}"{w_attr}{h_attr} role="img">
{extra}{bg_rect}{body}
</svg>'''


def icon_group(key, mono=False):
    o = OPTIONS[key]
    return ICON_FUNCS[key](o["green"], o["accent"], mono)


def lockup_svg(key, with_nyc=False):
    o = OPTIONS[key]
    icon = icon_group(key)
    name = "FREEDOM LAB"
    width = 1800 if with_nyc else 1600
    text_x = 500
    word_size = 190 if key in ("01-signal-torch", "04-open-flame") else 140
    base = f'''<g transform="translate(24 10) scale(.92)">{icon}</g>
<text x="{text_x}" y="275" fill="{o['green']}" font-family="{o['font']}" font-size="{word_size}" font-weight="800" letter-spacing="{o['tracking']}">{name}</text>'''
    if with_nyc:
        base += f'''<rect x="{text_x}" y="320" width="1040" height="14" rx="7" fill="{o['green']}" opacity=".25"/>
<text x="{text_x}" y="420" fill="{o['accent']}" font-family="{o['font']}" font-size="108" font-weight="800" letter-spacing="12">NYC</text>'''
    return svg_doc(base, f"0 0 {width} 512", width=width, height=512)


def board_svg(key):
    o = OPTIONS[key]
    icon = icon_group(key)
    mono_icon = icon_group(key, mono=True)
    display_size = 142 if key in ("01-signal-torch", "04-open-flame") else 116
    secondary_size = 112 if key in ("01-signal-torch", "04-open-flame") else 102
    word = f'''<text x="710" y="420" fill="{o['green']}" font-family="{o['font']}" font-size="{display_size}" font-weight="800" letter-spacing="{o['tracking']}">FREEDOM LAB</text>'''
    word_nyc = f'''<text x="710" y="610" fill="{o['green']}" font-family="{o['font']}" font-size="{secondary_size}" font-weight="800" letter-spacing="{o['tracking']}">FREEDOM LAB</text>
<text x="713" y="710" fill="{o['accent']}" font-family="{o['font']}" font-size="74" font-weight="800" letter-spacing="10">NYC</text>'''
    body = f'''
<rect x="54" y="50" width="1492" height="900" rx="34" fill="none" stroke="{o['green']}" stroke-opacity=".22" stroke-width="2"/>
<text x="100" y="130" fill="{o['accent']}" font-family="Avenir Next, Arial, sans-serif" font-size="38" font-weight="800" letter-spacing="6">{o['number']}</text>
<text x="190" y="130" fill="{o['fg']}" font-family="Avenir Next, Arial, sans-serif" font-size="56" font-weight="750">{escape(o['name'])}</text>
<text x="100" y="188" fill="{o['fg']}" fill-opacity=".68" font-family="Avenir Next, Arial, sans-serif" font-size="27">{escape(o['thesis'])}</text>
<g transform="translate(110 270) scale(.92)">{icon}</g>
{word}
{word_nyc}
<line x1="710" y1="770" x2="1450" y2="770" stroke="{o['fg']}" stroke-opacity=".14"/>
<text x="710" y="820" fill="{o['fg']}" fill-opacity=".55" font-family="Avenir Next, Arial, sans-serif" font-size="22" letter-spacing="3">ONE COLOR</text>
<g transform="translate(710 840) scale(.16)">{mono_icon}</g>
<text x="820" y="900" fill="{o['fg']}" fill-opacity=".55" font-family="Avenir Next, Arial, sans-serif" font-size="22">16 / 32 / 64 px stress-tested separately</text>
'''
    return svg_doc(body, "0 0 1600 1000", width=1600, height=1000, bg=o["bg"])


def write_all():
    for key, o in OPTIONS.items():
        icon = svg_doc(icon_group(key), "0 0 512 512", width=512, height=512)
        mono = svg_doc(icon_group(key, mono=True), "0 0 512 512", width=512, height=512)
        (SVG_DIR / f"{key}-icon.svg").write_text(icon)
        (SVG_DIR / f"{key}-icon-mono.svg").write_text(mono)
        (SVG_DIR / f"{key}-freedom-lab.svg").write_text(lockup_svg(key, False))
        (SVG_DIR / f"{key}-freedom-lab-nyc.svg").write_text(lockup_svg(key, True))
        (SVG_DIR / f"{key}-board.svg").write_text(board_svg(key))


if __name__ == "__main__":
    write_all()
    print(f"Wrote {len(OPTIONS) * 5} SVG files to {SVG_DIR}")
